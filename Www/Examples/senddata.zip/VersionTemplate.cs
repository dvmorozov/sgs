﻿
using System;

namespace SendData
{
    public class RationalCityPostExampleVersion
    {
        private static String version = "Version 1.1.0.$WCREV$";

        public static String ToString() { return version; }
    }
}