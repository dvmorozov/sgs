﻿
using System;

namespace SendData
{
    public class RationalCityPostExampleVersion
    {
        private static String version = "Version 1.1.0.1324";

        public static String ToString() { return version; }
    }
}